# Tube Companion (Android 7+)

A lightweight, dark-themed Android companion app that opens YouTube links in the official YouTube app when possible, otherwise in a browser.

## Requirements
- Android Studio with Android SDK installed
- JDK 11 (or the JDK bundled with a compatible Android Studio version)
- Android 7.0 / API 24 or newer on the target phone

## Build an APK
1. Extract this ZIP on a computer.
2. Open the `TubeCompanionAndroid` folder in Android Studio.
3. Allow Gradle sync to finish and install any requested Android SDK platform (compile SDK 33).
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio shows a notification with **locate**. The debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer the APK to the phone. Open it and allow installation from that file manager/source if Android asks. Install it.

## Notes
- This is source code for an Android project, not a prebuilt APK.
- It intentionally does not imitate the complete YouTube interface or bypass YouTube's rules.
- Search and feature links open YouTube externally. Account, recommendations, comments, subscriptions, and playback are provided by YouTube itself.
- For safety, only install APKs you built yourself or trust.
