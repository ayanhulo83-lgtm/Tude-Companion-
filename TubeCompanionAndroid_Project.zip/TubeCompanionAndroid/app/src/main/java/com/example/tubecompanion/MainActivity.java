package com.example.tubecompanion;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.inputmethod.EditorInfo;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.*;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(16,16,16);
    private final int PANEL = Color.rgb(34,34,34);
    private final int WHITE = Color.WHITE;
    private final int MUTED = Color.rgb(190,190,190);
    private final int RED = Color.rgb(255,55,55);
    private EditText search;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(14), dp(18), dp(24));
        scroll.addView(root);
        setContentView(scroll);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo = new TextView(this);
        logo.setText("▶");
        logo.setTextColor(RED);
        logo.setTextSize(27);
        logo.setTypeface(null, Typeface.BOLD);
        top.addView(logo);
        TextView title = new TextView(this);
        title.setText(" Tube Companion");
        title.setTextColor(WHITE);
        title.setTextSize(23);
        title.setTypeface(null, Typeface.BOLD);
        top.addView(title);
        root.addView(top, new LinearLayout.LayoutParams(-1, dp(48)));

        TextView note = new TextView(this);
        note.setText("A lightweight shortcut hub for YouTube");
        note.setTextColor(MUTED);
        note.setTextSize(14);
        note.setPadding(0, dp(2), 0, dp(16));
        root.addView(note);

        search = new EditText(this);
        search.setSingleLine(true);
        search.setTextColor(WHITE);
        search.setHintTextColor(MUTED);
        search.setHint("Search videos, channels, topics…");
        search.setTextSize(16);
        search.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        search.setPadding(dp(14), 0, dp(14), 0);
        search.setBackground(round(PANEL, 12));
        root.addView(search, new LinearLayout.LayoutParams(-1, dp(52)));
        search.setOnEditorActionListener((v, action, event) -> {
            String q = search.getText().toString().trim();
            if (!q.isEmpty()) openUrl("https://www.youtube.com/results?search_query=" + Uri.encode(q));
            hideKeyboard();
            return true;
        });

        Button searchButton = button("Search YouTube", RED);
        root.addView(searchButton, lpTop(10, 48));
        searchButton.setOnClickListener(v -> {
            String q = search.getText().toString().trim();
            if (q.isEmpty()) openUrl("https://www.youtube.com");
            else openUrl("https://www.youtube.com/results?search_query=" + Uri.encode(q));
            hideKeyboard();
        });

        section(root, "EXPLORE");
        addTile(root, "▶   Open YouTube", "Open the official YouTube app if available", () -> openYouTube());
        addTile(root, "⌕   Trending & popular", "Browse popular videos on YouTube", () -> openUrl("https://www.youtube.com/feed/trending"));
        addTile(root, "▣   Shorts", "Open Shorts in YouTube", () -> openUrl("https://www.youtube.com/shorts"));
        addTile(root, "◎   Subscriptions", "See your subscriptions after signing in", () -> openUrl("https://www.youtube.com/feed/subscriptions"));
        addTile(root, "▤   Your library", "History, playlists and saved videos", () -> openUrl("https://www.youtube.com/feed/library"));

        section(root, "QUICK SEARCHES");
        addTile(root, "🎮   Gaming", "Find gameplay and gaming channels", () -> searchFor("mobile gaming"));
        addTile(root, "🎵   Music", "Find music and performances", () -> searchFor("music"));
        addTile(root, "📚   Learning", "Find tutorials and educational videos", () -> searchFor("educational videos"));

        TextView footer = new TextView(this);
        footer.setText("This is an independent companion app, not an official YouTube product. Video playback, accounts and creator features are handled by YouTube.");
        footer.setTextColor(MUTED);
        footer.setTextSize(12);
        footer.setPadding(dp(4), dp(18), dp(4), dp(8));
        root.addView(footer);
    }

    private void section(LinearLayout root, String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(RED);
        t.setTextSize(12);
        t.setTypeface(null, Typeface.BOLD);
        t.setLetterSpacing(0.08f);
        t.setPadding(2, dp(24), 0, dp(8));
        root.addView(t);
    }

    private void addTile(LinearLayout root, String heading, String subtitle, Runnable action) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(12), dp(14), dp(12));
        card.setBackground(round(PANEL, 12));
        TextView h = new TextView(this);
        h.setText(heading);
        h.setTextColor(WHITE);
        h.setTextSize(16);
        h.setTypeface(null, Typeface.BOLD);
        card.addView(h);
        TextView s = new TextView(this);
        s.setText(subtitle);
        s.setTextColor(MUTED);
        s.setTextSize(12);
        s.setPadding(0, dp(4), 0, 0);
        card.addView(s);
        LinearLayout.LayoutParams p = lpTop(7, -2);
        root.addView(card, p);
        card.setClickable(true);
        card.setFocusable(true);
        card.setOnClickListener(v -> action.run());
    }

    private Button button(String text, int color) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(14);
        b.setAllCaps(false);
        b.setTypeface(null, Typeface.BOLD);
        b.setBackground(round(color, 12));
        return b;
    }

    private android.graphics.drawable.GradientDrawable round(int color, int radius) {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }

    private LinearLayout.LayoutParams lpTop(int top, int height) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, height);
        p.topMargin = dp(top);
        return p;
    }

    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }

    private void openYouTube() {
        Intent app = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com"));
        app.setPackage("com.google.android.youtube");
        try { startActivity(app); }
        catch (Exception e) { openUrl("https://www.youtube.com"); }
    }

    private void openUrl(String url) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "No app available to open this link.", Toast.LENGTH_LONG).show();
        }
    }

    private void searchFor(String q) {
        search.setText(q);
        openUrl("https://www.youtube.com/results?search_query=" + Uri.encode(q));
    }

    private void hideKeyboard() {
        try {
            ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE))
                .hideSoftInputFromWindow(search.getWindowToken(), 0);
        } catch (Exception ignored) {}
    }
}
